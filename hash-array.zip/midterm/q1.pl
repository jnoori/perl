
#!/usr/bin/perl
# countlines.pl by Bill Weinman <http://bw.org/contact/>

use 5.18.0;
use warnings;
$| = 1; #flushing the buffer
# use a scalar variable for the name of the file

my $str = "";
# Getting an food from the user
print "please enter a food \n";
$str = <STDIN>;
for(my $i = 0; $i < 4; $i++){
    my $st = <STDIN>;
    $str = $str.",".$st;
}
my @food = split(',', $str);
# displaying result using foreach loop
foreach (@food) {
  print "$_";
}
print @food;
print "first element= ". $food[0];
print "last element= ". $food[scalar(@food)-1];
print "length of array= ". scalar(@food). "\n";

# Using slicing method 
my @extracted_elements = @food[0...2];
print "first 3 elements: \n";
foreach (@extracted_elements) {
  print "$_ ";
}




