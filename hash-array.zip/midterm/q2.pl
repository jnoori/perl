
#!/usr/bin/perl
# countlines.pl by Bill Weinman <http://bw.org/contact/>

use 5.18.0;
use warnings;
use Data::Dumper qw(Dumper);
$| = 1; #flushing the buffer

my @names =qw( Nick Susan Chet Dolly Bill);
#Replace “Susan” and “Chet” with “Ellie”, “Beatrice”, and “Charles”
splice @names, 1, 2;
splice @names, 1, 1, 'Ellie', 'Beatrice', 'Charles';
print @names;
print "\n";

# remove Bill
splice @names, 2,1;
print @names;
print "\n";

#Add “Lewis“ and “Izzy” to the end of the array
push(@names, 'Lewis', 'Izzy');
print @names;
print "\n";

#Remove “Nick” from the beginning of the array
splice @names, 0,1;
print @names;
print "\n";

#Reverse the array
my @rev = reverse @names;
print @rev;
print "\n";

#Add “Archie” to the beginning of the array
unshift(@names, 'Archie'); 
print @names;
print "\n";

#Sort the array
my @sortArray = sort { $a cmp $b } @names;
print @sortArray;
print "\n";

#Replace “Chet” and “Dolly” with “Christian” and “Daniel”
@names =qw( Nick Susan Chet Dolly Bill);
splice @names, 2, 2;
splice @names, 2, 0, 'Christian', 'Daniel';
print @names;
print "\n";