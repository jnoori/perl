
#!/usr/bin/perl
# countlines.pl by Bill Weinman <http://bw.org/contact/>

use 5.18.0;
use warnings;
$| = 1; #flushing the buffer

my %players = (
    Ronaldo => 36,
    Messi => 23,
    Mbappe => 28,
    Neymar => 16,
    Salah => 20,
    Vardy => 19,
);

foreach my $name (sort { $players{$b} <=> $players{$a} } keys %players) {
    printf "%-8s %s\n", $name, $players{$name};
}



