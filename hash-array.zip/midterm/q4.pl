
#!/usr/bin/perl
# countlines.pl by Bill Weinman <http://bw.org/contact/>

use 5.18.0;
use warnings;
$| = 1; #flushing the buffer
# use a scalar variable for the name of the file

my @colors = qw(red green blue yellow pink purple brown);
my @drop = qw(pink brown);

for(my $i = 0; $i < scalar(@colors); $i++) {
    for(my $j = 0; $j < scalar(@drop); $j++){
        if($colors[$i] eq $drop[$j]){
            $colors[$i] ="";
        }
    }
}
print @colors;



