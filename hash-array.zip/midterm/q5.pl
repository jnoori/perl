
#!/usr/bin/perl
# countlines.pl by Bill Weinman <http://bw.org/contact/>

use 5.18.0;
use warnings;
$| = 1; #flushing the buffer

sub uniq {
    my %seen;
    grep !$seen{$_}++, @_;
}
my @array = qw ( a b c d d a e b a b d e f f e a);
my @filtered = uniq(@array);
print "@filtered\n";


